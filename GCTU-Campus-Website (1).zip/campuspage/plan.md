# GCTU Campus Guide — Plan

## Scope and implementation

Build one responsive, student-friendly information page for Ghana Communication Technology University (GCTU), focused on the main Tesano campus in Accra. It will use concise information checked against the university's official website and clearly link back to official pages for deeper details. It will include headings and paragraphs; inline text formatting such as bold, italic, and highlighted text; links; real campus photos; visible style attributes such as alignment, color, and background; and comments in the source.

Use the existing React, TypeScript, Vite, Tailwind, and Lucide setup without adding dependencies or enabling a backend/database. The existing `/` route in `client/src/App.tsx` will render `client/src/pages/Home.tsx`. Add the page's responsive visual system to `client/src/index.css`, refine title/description metadata in `client/index.html`, and place campus photos in `client/public/`. Add and keep `client/public/manus-routes.json` synchronized with the sole page route. Serve the static app on the already configured port 3000 with the starter's static development command.

Page content will cover a short GCTU introduction, verified institutional milestones, academic schools, student resources, and main-campus contact/location information. The official history page says the institution began as the Ghana Telecom Training Centre in 1948, gained institutional accreditation as Ghana Telecom University College in March 2005, and was inaugurated in August 2006. The official site currently lists the main campus at Tesano, Accra, PMB 100, Accra-North; email info@gctu.edu.gh; reception numbers 0303 940 305 and 0303 940 446; and admissions Call/WhatsApp 0501 579 732. The homepage lists the Faculty of Computing and Information Systems, Faculty of Engineering, GCTU Business School, School of Graduate Studies and Research, and Institute of Continuing and Distance Education. Link student portal, LMS, library, programmes, and admissions to GCTU-owned destinations. Avoid inventing student-life services or unverified campus facilities.

Use two selected GCTU campus images from official-site search results. The main entrance image will link to the official GCTU gatehouse article. Give images descriptive alt text and captions. Use a typographic GCTU wordmark rather than creating an unofficial institutional logo.

## Design direction

Three possible styles:
- Swiss academic editorial, with restrained typography and crisp information hierarchy (probability 0.07).
- Digital-campus wayfinding, with map-like labels and campus-signage patterns (probability 0.05).
- Contemporary West African university prospectus, with warm daylight photography and vivid school colors (probability 0.08).

Chosen style: **Swiss academic editorial**.

**Design Movement:** Swiss editorial design adapted for a contemporary university information page.

**Core Principles:** Make key campus facts easy to scan; reserve decoration for meaningful labels; provide clear contrast and accessible spacing; treat sourced imagery and links as useful information.

**Color Philosophy:** Use deep navy and bright gold accents echoing the tones visible in GCTU's campus imagery and institutional web presence, balanced with warm ivory and white for comfortable reading. Color should distinguish navigation, highlights, and calls to action rather than decorate every block.

**Layout Paradigm:** An editorial, left-aligned flow: a compact identity header, a large photo-led introduction, a narrow facts rail alongside the main narrative on wide screens, and full-width sections for schools and student links. Collapse into a single-column reading path on phones.

**Signature Elements:** A gold rule used as a section marker; small uppercase labels for location and date facts; generous, rounded campus-photo frames with clear captions.

**Interaction Philosophy:** Keep navigation familiar and anchor links direct. Calls to action open the university's own portal and information pages; email and telephone details use working `mailto:` and `tel:` links. No decorative or simulated controls.

**Animation:** Use only restrained hover transitions for links and buttons; respect reduced-motion preferences and avoid entrance effects that delay reading.

**Typography System:** Use a clean system sans-serif stack for body text and navigation, with a confident display serif for the main headline. Establish hierarchy through scale, weight, and line length rather than many font styles.

**Brand Essence:** A practical, welcoming guide to GCTU's Tesano campus for students and visitors; clear, lively, grounded.

**Brand Voice:** Direct, informed, and encouraging. Example lines: “A technology-led campus in Tesano, Accra.” “Find your school, student portal, and the right contact in a few clicks.”

**Wordmark & Logo:** Set “GCTU” in a bold typographic wordmark paired with the full university name and a small location descriptor. Do not redraw or imply an official seal.

**Signature Brand Color:** Deep campus navy, used as the anchor for the header, links, and key calls to action.

## Sources for verified page copy and links

- GCTU official homepage: https://site.gctu.edu.gh/
- GCTU official campus page: https://site.gctu.edu.gh/uncategorized/tesano-campus.aspx
- GCTU official contact page: https://site.gctu.edu.gh/contact-us
- GCTU official history: https://site.gctu.edu.gh/gtuc/administration/gtuc-history/
- Official gatehouse article for the selected entrance image: https://site.gctu.edu.gh/news/gctu-gets-new-groundbreaking-gatehouse.aspx
