import {
  ArrowRight,
  ArrowUpRight,
  BookOpen,
  Building2,
  GraduationCap,
  Landmark,
  Library,
  Mail,
  MapPin,
  Phone,
} from "lucide-react";

const schools = [
  {
    number: "01",
    name: "Faculty of Computing and Information Systems",
    short: "FoCIS",
    href: "https://focis.gctu.edu.gh/",
    description: "Explore computing and information systems at GCTU.",
    icon: Building2,
  },
  {
    number: "02",
    name: "Faculty of Engineering",
    short: "Engineering",
    href: "https://foe.gctu.edu.gh/",
    description: "Visit the Faculty of Engineering's official site.",
    icon: Landmark,
  },
  {
    number: "03",
    name: "GCTU Business School",
    short: "Business",
    href: "https://gbs.gctu.edu.gh/",
    description: "Find programmes and information from the Business School.",
    icon: GraduationCap,
  },
  {
    number: "04",
    name: "School of Graduate Studies and Research",
    short: "Graduate studies",
    href: "https://gs.gctu.edu.gh/",
    description: "Explore postgraduate study and research at GCTU.",
    icon: BookOpen,
  },
  {
    number: "05",
    name: "Institute of Continuing and Distance Education",
    short: "ICDE",
    href: "https://icde.gctu.edu.gh/",
    description: "Learn more about continuing and distance education.",
    icon: Library,
  },
];

const studentLinks = [
  { name: "Student portal", note: "Registration and student services", href: "https://sip.gctu.edu.gh/" },
  { name: "Learning management system", note: "Courses and online learning", href: "https://lms.gctu.edu.gh/" },
  { name: "University library", note: "Library resources and services", href: "https://library.gctu.edu.gh/" },
  { name: "Programmes", note: "Browse GCTU study options", href: "https://site.gctu.edu.gh/gctu-programmes" },
  { name: "Admissions", note: "Applications and entry information", href: "https://site.gctu.edu.gh/admissions-office" },
];

const history = [
  { year: "1948", title: "A telecommunications training centre", text: "GCTU traces its roots to the Ghana Telecom Training Centre, established to train telecommunications technicians." },
  { year: "2005", title: "Institutional accreditation", text: "The official history records institutional accreditation as Ghana Telecom University College in March 2005." },
  { year: "2006", title: "University College inauguration", text: "The institution was inaugurated on 15 August 2006, continuing its growth in technology-focused education." },
];

export default function Home() {
  return (
    <div className="campus-site">
      {/* This page intentionally demonstrates HTML text formatting, links, images, styling and source comments. */}
      <a className="skip-link" href="#main-content">Skip to main content</a>

      <header className="site-header">
        <div className="header-inner">
          <a className="wordmark" href="#top" aria-label="GCTU Campus Guide home">
            <span className="wordmark-copy">
              <strong>GCTU</strong>
              <small>GHANA COMMUNICATION TECHNOLOGY UNIVERSITY · TESANO</small>
            </span>
          </a>
          <nav className="main-nav" aria-label="Main navigation">
            <a href="#overview">Overview</a>
            <a href="#schools">Schools</a>
            <a href="#student-life">Student links</a>
            <a href="#visit">Visit</a>
          </nav>
          <a className="header-cta" href="https://site.gctu.edu.gh/" target="_blank" rel="noreferrer">
            Official website <ArrowUpRight size={15} aria-hidden="true" />
          </a>
        </div>
      </header>

      <main id="main-content">
        <section className="hero" id="top" aria-labelledby="hero-title">
          <div className="hero-inner">
            <div className="hero-copy">
              <p className="eyebrow"><span className="eyebrow-dot" /> MAIN CAMPUS <span className="eyebrow-divider">/</span> TESANO, ACCRA</p>
              <h1 id="hero-title">A campus for a <em>connected</em> future.</h1>
              <p className="hero-intro">
                Get to know <strong>Ghana Communication Technology University</strong>—a technology-focused university in the heart of Accra.
              </p>
              <div className="hero-actions">
                <a className="button button-gold" href="#overview">Explore the campus <ArrowRight size={17} aria-hidden="true" /></a>
                <a className="text-link hero-text-link" href="https://site.gctu.edu.gh/gctu-programmes" target="_blank" rel="noreferrer">Browse programmes <ArrowUpRight size={15} aria-hidden="true" /></a>
              </div>
              <p className="hero-note" style={{ textAlign: "left" }}>
                Rooted in technology. <mark>Open to possibility.</mark>
              </p>
            </div>

            <figure className="hero-photo">
              <a href="https://site.gctu.edu.gh/news/gctu-gets-new-groundbreaking-gatehouse.aspx" target="_blank" rel="noreferrer" aria-label="Read GCTU's official article about the main gatehouse">
                <img src="/images/gctu-gatehouse.jpg" alt="The main gatehouse entrance at Ghana Communication Technology University in Tesano." />
                <span className="photo-corner-label">GCTU <ArrowUpRight size={15} aria-hidden="true" /></span>
              </a>
              <figcaption><span>01 / 02</span> Tesano campus entrance <span className="caption-source">Photo links to GCTU's gatehouse article</span></figcaption>
            </figure>
          </div>
          <div className="hero-bottomline" aria-hidden="true"><span>LEARN</span><span>CONNECT</span><span>CREATE</span></div>
        </section>

        <section className="quick-facts" aria-label="Campus quick facts">
          <div className="fact-item"><span className="fact-icon"><MapPin size={18} aria-hidden="true" /></span><span><small>MAIN CAMPUS</small><strong>Tesano, Accra</strong></span></div>
          <div className="fact-item"><span className="fact-icon"><Landmark size={18} aria-hidden="true" /></span><span><small>ROOTS</small><strong>Telecommunications training</strong></span></div>
          <div className="fact-item"><span className="fact-icon"><GraduationCap size={18} aria-hidden="true" /></span><span><small>STUDY OPTIONS</small><strong>From access courses to doctoral study</strong></span></div>
          <a className="fact-more" href="#visit">Plan a visit <ArrowRight size={16} aria-hidden="true" /></a>
        </section>

        <section className="section overview-section" id="overview" aria-labelledby="overview-title">
          <div className="section-kicker"><span>THE UNIVERSITY</span><span className="kicker-line" /></div>
          <div className="overview-grid">
            <div className="section-heading-block">
              <h2 id="overview-title">Technology is part of the story. <em>People are the point.</em></h2>
              <p className="lead-copy">GCTU describes its approach as technology-based education that brings theory and practice together across telecommunications, business, and ICT.</p>
              <a className="text-link" href="https://site.gctu.edu.gh/gtuc/administration/about-gtuc/" target="_blank" rel="noreferrer">About GCTU <ArrowUpRight size={15} aria-hidden="true" /></a>
            </div>
            <div className="overview-note" style={{ backgroundColor: "var(--gold-soft)" }}>
              <span className="note-mark" aria-hidden="true">“</span>
              <p><strong>Knowledge comes from learning.</strong></p>
              <p className="note-small">A phrase shared on GCTU's official Tesano campus page.</p>
              <a href="https://site.gctu.edu.gh/uncategorized/tesano-campus.aspx" target="_blank" rel="noreferrer">Read the campus page <ArrowUpRight size={14} aria-hidden="true" /></a>
            </div>
          </div>
        </section>

        <section className="history-band" aria-labelledby="history-title">
          <div className="history-heading">
            <div className="section-kicker section-kicker-light"><span>A BRIEF HISTORY</span><span className="kicker-line" /></div>
            <h2 id="history-title">A long line of <em>learning.</em></h2>
            <p>GCTU's story begins with technical training and continues through higher education and research.</p>
            <a className="text-link text-link-light" href="https://site.gctu.edu.gh/gtuc/administration/gtuc-history/" target="_blank" rel="noreferrer">Read GCTU's history <ArrowUpRight size={15} aria-hidden="true" /></a>
          </div>
          <div className="timeline">
            {history.map((item) => (
              <article className="timeline-item" key={item.year}>
                <span className="timeline-year">{item.year}</span>
                <div><h3>{item.title}</h3><p>{item.text}</p></div>
              </article>
            ))}
          </div>
        </section>

        <section className="section schools-section" id="schools" aria-labelledby="schools-title">
          <div className="section-topline">
            <div>
              <div className="section-kicker"><span>FIND YOUR FIELD</span><span className="kicker-line" /></div>
              <h2 id="schools-title">Schools &amp; faculties</h2>
            </div>
            <p className="section-side-copy">GCTU lists professional, diploma, undergraduate, master's and doctoral programmes across its academic schools.</p>
          </div>
          <div className="schools-list">
            {schools.map((school) => {
              const Icon = school.icon;
              return (
                <a className="school-row" href={school.href} target="_blank" rel="noreferrer" key={school.number}>
                  <span className="school-number">{school.number}</span>
                  <span className="school-icon"><Icon size={20} strokeWidth={1.7} aria-hidden="true" /></span>
                  <span className="school-copy"><small>{school.short}</small><strong>{school.name}</strong><span>{school.description}</span></span>
                  <ArrowUpRight className="school-arrow" size={19} aria-hidden="true" />
                </a>
              );
            })}
          </div>
          <p className="section-footnote">School names and links are taken from the <a href="https://site.gctu.edu.gh/" target="_blank" rel="noreferrer">official GCTU website</a>.</p>
        </section>

        <section className="student-band" id="student-life" aria-labelledby="student-title">
          <div className="student-intro">
            <div className="section-kicker section-kicker-light"><span>YOUR CAMPUS SHORTCUTS</span><span className="kicker-line" /></div>
            <h2 id="student-title">The right link, <em>right here.</em></h2>
            <p>Go straight to official GCTU learning and student resources.</p>
            <div className="student-stamp"><span className="stamp-icon"><BookOpen size={19} aria-hidden="true" /></span><span>STUDENT<br />RESOURCES</span></div>
          </div>
          <div className="student-links">
            {studentLinks.map((link, index) => (
              <a className="student-link" href={link.href} target="_blank" rel="noreferrer" key={link.name}>
                <span className="student-link-number">0{index + 1}</span>
                <span className="student-link-copy"><strong>{link.name}</strong><small>{link.note}</small></span>
                <ArrowUpRight size={17} aria-hidden="true" />
              </a>
            ))}
          </div>
        </section>

        <section className="section visit-section" id="visit" aria-labelledby="visit-title">
          <div className="visit-heading">
            <div className="section-kicker"><span>COME FIND US</span><span className="kicker-line" /></div>
            <h2 id="visit-title">Meet us in <em>Tesano.</em></h2>
            <p>Use GCTU's current contact details below to reach the main campus or admissions team.</p>
            <a className="button button-navy" href="https://www.google.com/maps/search/?api=1&query=Ghana+Communication+Technology+University+Tesano+Accra" target="_blank" rel="noreferrer">Open campus map <ArrowUpRight size={16} aria-hidden="true" /></a>
          </div>
          <figure className="visit-photo">
            <img src="/images/gctu-campus-view.jpg" alt="A view of the entrance and grounds at GCTU's Tesano campus." loading="lazy" />
            <figcaption>Campus view <span>Ghana Communication Technology University</span></figcaption>
          </figure>
          <address className="contact-card">
            <span className="contact-card-label">MAIN CAMPUS</span>
            <strong>GCTU, Tesano</strong>
            <span className="address-lines">Accra, Ghana<br />PMB 100, Accra-North</span>
            <span className="digital-address">Digital Address <b>GA-167-2979</b></span>
            <a href="mailto:info@gctu.edu.gh"><Mail size={16} aria-hidden="true" /> info@gctu.edu.gh</a>
            <a href="tel:+233303940305"><Phone size={16} aria-hidden="true" /> 0303 940 305</a>
            <a href="tel:+233303940446"><Phone size={16} aria-hidden="true" /> 0303 940 446</a>
            <div className="admissions-contact"><small>ADMISSIONS · CALL / WHATSAPP</small><a href="tel:+233501579732">0501 579 732 <ArrowRight size={15} aria-hidden="true" /></a></div>
          </address>
        </section>

        <section className="source-strip" aria-label="Information sources">
          <span>DETAILS CHECKED AGAINST</span>
          <a href="https://site.gctu.edu.gh/" target="_blank" rel="noreferrer">GCTU official website <ArrowUpRight size={13} aria-hidden="true" /></a>
          <a href="https://site.gctu.edu.gh/contact-us" target="_blank" rel="noreferrer">Contact page <ArrowUpRight size={13} aria-hidden="true" /></a>
          <a href="https://site.gctu.edu.gh/gtuc/administration/gtuc-history/" target="_blank" rel="noreferrer">History page <ArrowUpRight size={13} aria-hidden="true" /></a>
        </section>
      </main>

      <footer className="site-footer">
        <a className="footer-wordmark" href="#top">GCTU <span>CAMPUS GUIDE</span></a>
        <p>Ghana Communication Technology University · Tesano, Accra</p>
        <span className="footer-note">An independent student guide · Always confirm updates with GCTU</span>
      </footer>
    </div>
  );
}
