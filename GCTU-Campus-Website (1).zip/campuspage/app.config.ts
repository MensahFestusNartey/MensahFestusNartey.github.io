export default {
  logoUrl: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663816957474/WVBxerMGPqlsiCet.svg",
};
